const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
	firstName: {
		type: String,
		required: true,
		minlength: [3,"First name contain at least 3 characters!"],
		maxlength:[12 ,"Name must contain 12 characters"],
		validate:{
			validator: function(value){
				return /^[a-zA-Z]+$/.test(value);
			},
			message:"Name is not valid"
		}
	},
	lastName: {
		type: String,
		required: true,
		minlength: [3,"First name contain at least 3 characters!"],
		maxlength:[12 ,"Name must contain 12 characters"],
		validate:{
			validator: function(value){
				return /^[a-zA-Z]+$/.test(value);
			},
			message:"Name is not valid"
		}
	},
	email: {
		type: String,
		required: true
	},
	password: {
		type: String,
		required: true
	},
	gender: {
		type: String,
		enum: ["male", "female"]
	},
	address: String,
	
	phone: Number,
	joinedTime: {
		type: Date,
		default: Date.now
	},
	role: {
		type: String,
		enum: ["admin", "donor", "agent","ngo"],
		required: true
	},
	token: {
		type: String,
		default:''
		
	}
},{
	timestamp: true,
});

const User = mongoose.model("users", userSchema);
module.exports = User;